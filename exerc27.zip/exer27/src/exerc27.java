import java.util.Scanner;

public class exerc27 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe o preço de fábrica do veiculo");

        float fabrica = scanner.nextInt();

        System.out.println("informe o percentual de lucro do distribuidor");

        float lucro = scanner.nextInt();

        System.out.println("informe o percentual do imposto");

        int imposto = scanner.nextInt();

        float blabla = imposto/100;

        float venda = fabrica * lucro;

        System.out.println("");

        System.out.print("o valor da venda eh de = " + venda);

        float lbruto = venda / fabrica;

        System.out.println("");
        //System.out.println(" lucro bruto do distribuidor eh de =" + lbruto);

      float lquido =  imposto - lbruto;

        //System.out.println(" lucro bruto do distribuidor eh de = " + lquido );
        System.out.println("");

        float perce = lbruto * fabrica /100;

        System.out.println("o lucro do distribuidor eh de =" + perce);

        System.out.println("");



        float impsts = venda = 1 - imposto;
        System.out.println("");
        System.out.println("o valor correspondente ao  imposto eh de =" + impsts +"%");
        System.out.println("");
        float fim = fabrica + perce + impsts;
        System.out.println("");

        System.out.print("o valor final do veiculo eh de =" + fim );


        System.out.println("");


    }
}
