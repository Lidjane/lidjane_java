import java.util.Scanner;

public class exerc23 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner (System.in);

        System.out.println("");

        System.out.println("informe o peso da pessoa");

        float peso = scanner.nextInt();

        float n = peso * 15 / 100;

        System.out.println("");

        System.out.println(" valor da percentagem se ela engordar = " + n );

           float novopeso = peso + n;

        System.out.println("");

           System.out.println("o novo peso da pessoa se engordar 15% eh de =" + novopeso +" kg");

           float novopeso2 = peso * 20 / 100;

        System.out.println("");

           float emagrecimento = peso - novopeso2;

           System.out.println("O novo peso da pessoa se ela emagrecer 20 % eh de = " + emagrecimento + "kg");
    }
}
