import java.util.Scanner;
public class exerc13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("informe o seu ano de nascimento");
        int anodenascimento = scanner.nextInt();
        System.out.println("infome o ano actual");
        int anoactual = scanner.nextInt();

        int idade = anoactual - anodenascimento;
         int idade2 = 2050 - anodenascimento;

         System.out.println("a idade da pessoa eh de =" + idade );
         System.out.println(" a pessoa em 2050 tera exatamente = " + idade2);
    }
}
