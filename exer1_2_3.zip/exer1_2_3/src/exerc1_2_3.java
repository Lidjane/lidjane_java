import java .util.Scanner;
public class exerc1_2_3{
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);


            //soma
            System.out.println("informe os 4 valores para somar");

            int valor1 = scanner.nextInt();
            int valor2 = scanner.nextInt();
            int valor3 = scanner.nextInt();
            int valor4 = scanner.nextInt();

            int soma = valor1+ valor2 + valor3+ valor4;
            System.out.println("A soma dos valores é =" + soma);

            //subtração

            System.out.println("informe os 2 valores para subtrair");

            float kaka1 = scanner.nextInt();
            float kaka2 = scanner.nextInt();

            float sub = kaka1 - kaka2;
            System.out.println("A soma dos dois valores é =" +  sub);

            //multiplicação

            System.out.println("informe os 3 valores para multiplicar");

            int numero1 = scanner.nextInt();
            int numero2 = scanner.nextInt();
            int numero3 = scanner.nextInt();

            int mult = numero1*numero2*numero3;
            System.out.println("o valor da muitiplicacao e =" + mult);
        }
    }



