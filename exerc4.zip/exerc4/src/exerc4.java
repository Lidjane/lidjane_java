import java.util.Scanner;
public class exerc4 {
        public static void main(String[] args) {

            Scanner scanner = new Scanner(System.in);

            System.out.println("informe os dois valores");

            int valor1 = scanner.nextInt();
            int valor2= scanner. nextInt();

            int div = valor1/valor2;

            if(valor2==0 || valor2<0){

                System.out.println("valor nulo");
            }

            System.out.println("o valor da divisão e=" + div);


        }
    }

