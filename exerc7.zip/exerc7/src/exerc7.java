import java.util.Scanner;

public class exerc7 {

    public static void main(String[] args) {

         Scanner scanner = new Scanner(System.in);

         System.out.println("informe a maior diagonal do losango");
           float dig1 = scanner.nextInt();
           System.out.println("informe a diagonal menor do losango");
           float dig2 = scanner.nextInt();

           float area = dig1 * dig2 / 2;

           System.out.println("A area do losango eh de=" + area);

    }
}
