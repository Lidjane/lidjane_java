import java.util.Scanner;

public class exerc14 {

    public static void main(String[] args) {

        Scanner scannerS = new Scanner(System.in);

        System.out.println("informe o ano de nascimento da pessoa");

          int anodenascimento = scannerS.nextInt();

          System.out.println("informe o ano actual");

            int anoactual = scannerS.nextInt();

             int idademanos =  anoactual - anodenascimento;

             System.out.println(" a idade da pessoa eh = " + idademanos);

             int idadeemmeses = idademanos * 12;

             System.out.println(" a idade da pessoa em meses eh de=" + idadeemmeses);

             int idadeemdias = idademanos * 365;

             System.out.println(" a idade da pessoa em dias e de =" + idadeemdias);

              int idadeemsemanas = idademanos * 48;

              System.out.println(" a idade da pessoa em semanas eh de=" + idadeemsemanas);


    }
}
