import java.util.Scanner;

public class exerc18 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

 System.out.println("informe o valor do produto");

  float valorproduto = scanner.nextInt();

     float  valordesconto = valorproduto * 10 / 100;

    // System.out.println(" o valor do desconto eh de = " + valordesconto);

     float preconovo = valorproduto - valordesconto;

     System.out.println("o valor do desconto eh de = " + preconovo);




    }
}
