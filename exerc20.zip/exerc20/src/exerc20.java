import java.util.Scanner;
public class exerc20 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe o custo do espetaculo");

         float custoespetaculo = scanner.nextInt();

         System.out.println("informe o valor do convite do espetaculo");

         float conviteespetaculo = scanner.nextInt();

         float convites = custoespetaculo / conviteespetaculo;

         System.out.print(" a quantidade de convites a ser vendido para que se chegue ao custo do espetaculo é de =" + convites);


    }
}
