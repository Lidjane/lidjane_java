import java.util.Scanner;

public class exerc12 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe o valor da base doa triangulo");
                int base = scanner.nextInt();
        System.out.println("informe a altura do triangulo");
          float altura = scanner.nextInt();

          float area = base * altura / 2;

          System.out.println(" o valor da area do triangulo e de=" + area);

    }
}
