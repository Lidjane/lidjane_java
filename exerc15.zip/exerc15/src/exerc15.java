import java.util.Scanner;
import math.pow.Scanner;
public class exerc15 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe dois valores maiores que zero");

         int numero1 = scanner.nextInt();
         int numero2 = scanner.nextInt();

      int elev = numero1^numero2;
 System.out.println(" " + elev);
}
}
