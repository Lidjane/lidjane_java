import java.util.Scanner;
public class exerc5 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("informe as 3 notas do aluno");

        float a = scanner.nextInt();
        float b = scanner.nextInt();
        float c = scanner.nextInt();

        float media = a + b + c / 3;
        System.out.println("o a media do aluno eh =" + media);

    }
}