import java.util.Scanner;

public class exerc19 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe o valor do salario do funcionario");

        float  salariodofuncionario = scanner.nextInt();

        System.out.println(" informe o valor do percentual");

        float valordopercentual = scanner.nextInt();

            float  percent = salariodofuncionario * valordopercentual / 100;

            System.out.println("O valor do aumento eh de = " + percent);

            float salarionovo = salariodofuncionario + percent;

            System.out.println("O valor do novo salario eh de = " + salarionovo);

    }


}
