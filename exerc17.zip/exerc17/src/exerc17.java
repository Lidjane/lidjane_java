import  java.util.Scanner;

public class exerc17 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe o salario do funcionario");

         float salario = scanner.nextInt();

         float salarionovo = salario * 25/100;

               //  System.out.println("o valor do novo salario eh = " + salarionovo);

        float novosalario = salario + salarionovo;

        System.out.println("o novo salario eh de = " + novosalario);




    }
}
