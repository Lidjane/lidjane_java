import java.util.Scanner;

public class exerc31 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);


        System.out.println("informe o salario minimo");

        float salarioMinimo = scanner.nextInt();

        System.out.println("");

        System.out.println("informe  a quantidade de quilowalt");

        float qntdadeDeqlw = scanner.nextInt();

        System.out.println("");

         float valorDeqw = salarioMinimo / 1/5;

        System.out.println("o valor de quilowalt é de =" +valorDeqw);

        System.out.println("");

      float  valorAserPago = qntdadeDeqlw + valorDeqw;

        System.out.println("o valor a ser pago por essa residencia e de=" +valorAserPago);

        System.out.println("");

       float desconto = valorAserPago * 15;
        //System.out.println(" " + desconto);

        System.out.println("");

        float pagar = valorAserPago - desconto;
        System.out.println("o valor a ser pago pela residencia depois de sofrer um desconto =" +pagar);

        System.out.println("");

    }

}
