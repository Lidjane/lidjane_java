

import java.util.Scanner;

public class exerc30 {

    public static void main(String[] args) {

        Scanner scanner  = new Scanner(System.in);


        System.out.println("informe o peso do saco em quilos");

      float pesosacos = scanner.nextInt();

        System.out.println("");

        System.out.println("informe a quantidade de ração fornecida a cada gato em kg");

        float quantidade = scanner.nextInt();

        System.out.println("");

        float quantidadeEmGramas = quantidade * 1000;

        System.out.println("a quantidade dada aos gatos em grama eh de =" + quantidadeEmGramas + "gramas");

        System.out.println("");

         float finalDeCincoDias = pesosacos - quantidade * 5;

        System.out.println(" no final de cinco dias sobrarão =" + finalDeCincoDias);






    }
}
