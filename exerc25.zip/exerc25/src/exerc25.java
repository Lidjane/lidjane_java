import java.util.Scanner;

public class exerc25 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe o valor dp deposito");

        float deposito = scanner.nextInt();

        System.out.println("informe o valor da taxa de juros");

        System.out.println("");

        int juros = scanner.nextInt();

        float rendimento = deposito *juros / 100;

        System.out.println("o valor do rendimento eh de = " + rendimento);

        // float rendimentototal =


    }
}
