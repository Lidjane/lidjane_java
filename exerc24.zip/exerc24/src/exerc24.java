import java.util.Scanner;

public class exerc24 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("");

        System.out.println("informe o valor do salario fixo");

        System.out.println("");

        float salariofixo = scanner.nextInt();

        System.out.println("");

        float novosalario = salariofixo + 50;

        System.out.println("");

        System.out.println("O valor do salario fixo com a gratificacao eh de = " + novosalario);

        float imposto = salariofixo * 10 / 100;

        System.out.println("");

        float salarioimposto = salariofixo - imposto;

        System.out.println("o valor do salario se lhe for descontado o imposto eh de =" + salarioimposto);


    }
}
