import java.util.Scanner;
public class exerc10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("informe a base maior do trapezio");
        int basemaior = scanner.nextInt();
        System.out.println("informe a base menor do trapezio");
          int basemenor = scanner.nextInt();
          System.out.println("informe a altura do trapezio");
          float altura = scanner.nextInt();

          float area = (basemaior + basemenor) * altura / 2;
          System.out.println("A area do trapezio eh igual a=" + area);
    }
}
