import java.util.Scanner;

public class exerc9 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe o peso da pessoa em kg");

           float peso = scanner. nextInt();

           float grama = peso * 1000;

           System.out.println(" o peso da pessoa em gramas eh de=" + grama + "gramas" );


    }
}
