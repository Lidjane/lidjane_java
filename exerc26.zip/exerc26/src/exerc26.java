import java.util.Scanner;

public class exerc26 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe um numero maior que zero");

           int numero = scanner.nextInt();

        System.out.println("");

       // int quadrado = numero * numero;

        System.out.println(" o valor do quadrado do numero eh ="  + Math.pow(numero,numero) );
        System.out.println("");

        int cubo = numero * numero * numero;

        System.out.println("o cubo do numero eh = " + cubo);

        System.out.println("");
        
    }
}
