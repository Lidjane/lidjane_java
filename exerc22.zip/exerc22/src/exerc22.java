import java.util.Scanner;

public class exerc22 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println(" informe o valor do salario fixo");

         float salariofixo = scanner.nextInt();

         System.out.println(" informe o valor das vendas");

         float vendas = scanner.nextInt();

         float comicao = vendas * 4 / 100;

        System.out.println("o valor da comicaco eh de = " + comicao);

         float sal = salariofixo + comicao;

         System.out.println("o valor do salario final eh de = " + sal);



    }
}
