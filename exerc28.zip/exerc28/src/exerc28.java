import java.util.Scanner;

public class exerc28 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe o número de horas trabalhadas");

        int horas = scanner.nextInt();
        System.out.println("");
        System.out.println("informe o salário minimo");

        float salario = scanner.nextInt();
        System.out.println("");

       float horatra = salario / 2;

       System.out.println(" o valor das horas trabalhadas equivale a= " + horatra);
        System.out.println("");

        float salbruto = horas * horatra;
        System.out.println("salário bruto equivale a =" + salbruto);
        System.out.println("");

       // float imposto = 3 /100;
       // System.out.println(" " + imposto);

        float imposto2 = salbruto * 3 / 100;
        System.out.println("o valor do imposto é =" + imposto2 );
        System.out.println("");

        float salreceber = salbruto - imposto2;

        System.out.println("o salário a receber é de =" + salreceber);
    }

}
