import java.util.Scanner;
public class exerc11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        System.out.println("inform o valor do salario mino");
        float salariminimo = scanner.nextInt();
        System.out.println("informe o salario do funcionario");
        float salariodofuncionario= scanner.nextInt();

        float quantidade = salariodofuncionario / salariminimo;

        System.out.println("A quantidade de salario minimo que esse funcionario ganha é de= " + quantidade);
    }
}
