import java.util.Scanner;
public class exerc6 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("informe a nota do aluno");
        float nota1 = scanner.nextInt();
        System.out.println("informe o peso da nota");
        float peso1 = scanner.nextInt();
        System.out.println("informe a nota do aluno");
        float nota2 = scanner.nextInt();
        System.out.println("informe o peso da nota");
        float peso2 = scanner.nextInt();
        System.out.println("informe a nota do aluno");
        float nota3 = scanner.nextInt();
        System.out.println("informe o peso da nota");
        float peso3 = scanner.nextInt();

        float mediaponderada = nota1*peso1 + nota2*peso2 + nota3*peso3 / peso1 + peso2 + peso3;

        System.out.println("A media ponderada do aluno eh=" + mediaponderada);

    }
}

