import java.util.Scanner;

public class exerc21 {

    public static void main(String[] args) {

        Scanner scanner =  new Scanner(System.in);

        System.out.println("informe o salario base do funcionario");

        float salariobase = scanner.nextInt();

        float salariogratificacao = salariobase * 5 / 100;

       // System.out.println("" + salariogratificacao);

        float grat = salariobase + salariogratificacao;

        System.out.println("");

        System.out.println(" o valor do salario a receber com a gratificacao eh de = " + grat);

        float imposto = salariobase * 7 /100;

        System.out.println("");

         System.out.println("O valor do imposto eh de = " + imposto);

         float receber = salariobase - imposto;

         System.out.println("");

         System.out.println("O valor do funcionario receber com o desconto do imposto eh de " + receber);

         



    }
}
